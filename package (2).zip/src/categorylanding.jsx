import React from "react";
import CatCards from "./catcards";
import data from './datajson.json';
import { useState } from "react";
import { Link } from 'react-router-dom';
import { useNavigate} from "react-router-dom";



function Categorylanding() {
  // console.log(data)
  const [catid ] = useState(window.location.href.split('=')[1])
  let navigate = useNavigate();
  const strAscending = [...data.Artists.Artist].sort((a, b) =>
     a.artistname > b.artistname ? 1 : -1,
    );
  return (
    <div>
      <div style={{marginTop:"100px",textAlign:'end'}}>
        <Link className="btn btn-primary btn-l text-uppercase" onClick={() => navigate(-1)}><i className="fas fa-arrow-left"></i> Back</Link>
      </div>
      <div className="container ">
        {data.Arts.Art.map((mydata) => {
          if(mydata.artid === catid){
            return( <h2 key='47' className="text-center">Category - {mydata.title}</h2>)
          }
          return ''
        }
        
        )}
        
        <div className="row">
          {strAscending.map((mydata) => {
            if(mydata.arts.artid.toString().indexOf(catid) !== -1){
              return(
                <div className="col-md-4 my-2" key={mydata.artistid}>
                  <CatCards name={mydata.artistname.replace(/\w+/g,
                      function(w){return w[0].toUpperCase() + w.slice(1).toLowerCase();})} desc={mydata.designation} email={mydata.email.toLowerCase()} contact={mydata.contact} link={`/category/detail/artist-${mydata.artistid}`} image={`${process.env.PUBLIC_URL}/assets/${mydata.imagepath}`}/>
                </div>
              )
            }else{return ''}
          })}
        </div>
      </div>
    </div>
  );
}

export default Categorylanding;