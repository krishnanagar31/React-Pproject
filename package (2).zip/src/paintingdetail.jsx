import { Link } from 'react-router-dom';
import data from './datajson.json';
import { useState } from 'react';
import { useNavigate} from "react-router-dom";

function PaintingDetail(props) {
  const [paintid] = useState(window.location.href.split('-')[1]-1)
  let navigate = useNavigate();
  return (
    <>
        <div style={{marginTop:"100px",textAlign:'end'}}>
        <Link className="btn btn-primary btn-l text-uppercase" onClick={() => navigate(-1)}><i className="fas fa-arrow-left"></i> Back</Link>
        </div>
      <div className="containerpt-2 text-center">
        <h3>{data.Items.Item[paintid].ItemName.replace(/\w+/g,
                      function(w){return w[0].toUpperCase() + w.slice(1).toLowerCase();})}</h3>
        <img src={`${process.env.PUBLIC_URL}/assets/${data.Items.Item[paintid].images.imagepath[0]}`} alt="" />
        {/* <h3>Description : </h3> */}
        <p className="p-3 h5 fw-light"> <strong className='fw-bold'>Description : </strong>{data.Items.Item[paintid].description}</p>
      </div>
    </>

  );
}

export default PaintingDetail;