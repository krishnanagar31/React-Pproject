import Detail from "./detail";
import Home from "./home";
import PaintingDetail from './paintingdetail'
import { Routes, Route } from "react-router-dom";
import Categorylanding from "./categorylanding";
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
// import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <>
      <nav
        className="navbar navbar-expand-lg navbar-dark fixed-top"
        id="mainNav"
      >
        <div className="container">
          <a className="navbar-brand" href="/">
            Art Gallary
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarResponsive"
            aria-controls="navbarResponsive"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            Menu
            <i className="fas fa-bars ms-1"></i>
          </button>
          <div className="collapse navbar-collapse" id="navbarResponsive">
            <ul className="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
              <li className="nav-item">
                <a className="nav-link" href="#category">
                  Category
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#about">
                  About
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#contact">
                  Contact
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/category/catlanding/*" element={<Categorylanding />} />
        <Route path="/category/detail/*" element={<Detail />} />
        <Route path="/category/paintdetail/*" element={<PaintingDetail />} />
      </Routes>
    </>
  );
}

export default App;
