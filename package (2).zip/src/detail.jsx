import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import data from './datajson.json';
import { useState } from 'react';
import { useNavigate} from "react-router-dom";

function Detail(props) {
  const [artistid] = useState(window.location.href.split('-')[1])
  let navigate = useNavigate();
  const strAscending = [...data.Items.Item].sort((a, b) =>
     a.ItemName > b.ItemName ? 1 : -1,
    );
  return (
    <>
      <div style={{marginTop:"100px",textAlign:'end'}}>
        <Link className="btn btn-primary btn-l text-uppercase" onClick={() => navigate(-1)}><i className="fas fa-arrow-left"></i> Back</Link>
      </div>
      <div className="container">
        {data.Artists.Artist.map((mydata) => {
          if (mydata.artistid === artistid) {
            return (<h2 key={mydata.artistid} className='text-center my-3'> Paintings by {mydata.artistname}</h2>)
          }
          return ''
        }
        )}

        <div className="row">
          {strAscending.map((ar) => {
            // console.log(artistid)
            if (ar.artists.artistid.toString().indexOf(artistid) !== -1) {
              return (
                <div className="col-md-4 my-3" key={ar.ItemID}>
                <Link to={`/category/paintdetail/painting-${ar.ItemID}`}>
                  <Card className="h-100" style={{ width: '300px' }}>

                    <Card.Body >

                      <Card.Title style={{

                        whiteSpace: "nowrap", width: "250px",

                        overflow: "hidden", textOverflow: "ellipsis", wordWrap: "break-word"

                      }}>{ar.ItemName.replace(/\w+/g,
                      function(w){return w[0].toUpperCase() + w.slice(1).toLowerCase();})}</Card.Title>

                    </Card.Body>

                    <Card.Img className='bordercustom' variant="top" style={{ height: "200px", width: "300px" }} src={`${process.env.PUBLIC_URL}/assets/${ar.images.imagepath[0]}`} />

                  </Card>
                </Link>

                </div>
              )
            }
            return ''
          })
          }

        </div>
      </div>
    </>
  );
}

export default Detail;