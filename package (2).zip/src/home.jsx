import React from "react";
import { Link } from 'react-router-dom';
import data from './datajson.json';

function Home() {
    const strAscending = [...data.Arts.Art].sort((a, b) =>
     a.title > b.title ? 1 : -1,
    );
  return (
    <>
        <header className="masthead">
            <div className="container">
                <div className="masthead-subheading">Welcome To Art Gallary!</div>
                <a className="btn btn-primary btn-xl text-uppercase" href="#category">Art Category</a>
            </div>
      </header>
        <section className="page-section" id="category">
            <div className="container">
                <div className="text-center">
                    <h2 className="section-heading text-uppercase">Art category</h2>
                    <h3 className="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
          </div>
          <div className="row text-center"> 
          {strAscending.map((country) => {
             return(
                    
                    <div className="col-md-4 pb-5" key={country.artid}>
                        <span className="fa-stack fa-4x">
                            <img src={`${process.env.PUBLIC_URL}/assets/catimg/${country.imagepath}`} alt="" className="rounded-circle" width="100" height="100" />
                        </span>
                 <h4><Link to={`/category/catlanding/${country.RedirectURL}`}>{country.title}</Link></h4>
                    </div>
            
           ) })}
            </div>
            </div>
        </section>
        <footer className="footer py-4">
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-lg-4 text-lg-start">Copyright &copy; Your Website 2023</div>
                    <div className="col-lg-4 my-3 my-lg-0">
                        <a className="btn btn-dark btn-social mx-2" href="#!" aria-label="Twitter"><i className="fab fa-twitter"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!" aria-label="Facebook"><i className="fab fa-facebook-f"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!" aria-label="LinkedIn"><i className="fab fa-linkedin-in"></i></a>
                    </div>
                    <div className="col-lg-4 text-lg-end">
                        <a className="link-dark text-decoration-none me-3" href="#!">Privacy Policy</a>
                        <a className="link-dark text-decoration-none" href="#!">Terms of Use</a>
                    </div>
                </div>
            </div>
        </footer>

    </>
  );
}

export default Home;
