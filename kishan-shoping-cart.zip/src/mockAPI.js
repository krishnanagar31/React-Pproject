const API = [
  {
    name: "Iphone 14 Pro",
    price: 90000,
    count: 0,
    counterVal: 1,
    inCart: false,
    img: "../iphone14.avif",
  },
  {
    name: "Samsung S23 Ultra",
    price: 70000,
    count: 0,
    counterVal: 1,
    inCart: false,
    img: "../s23.jpg",
  },
  {
    name: "OnePlus 10R",
    price: 50000,
    count: 0,
    counterVal: 1,
    inCart: false,
    img: "../10r.jpg",
  },
  {
    name: "Oppo A17",
    price: 30000,
    count: 0,
    counterVal: 1,
    inCart: false,
    img: "../oppo.png",
  },
];
export default API;
