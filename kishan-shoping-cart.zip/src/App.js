import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import API from "./mockAPI";
import "./App.css";

function App() {
  const [cart, setCart] = useState(API);

  const addToCart = (i) => {
    setCart((prevState) =>
      prevState.map((item, o) => {
        if (i === o) {
          return {
            ...item,
            inCart: true,
            count: item.counterVal,
          };
        }
        return item;
      })
    );
  };

  const increaseQuantity = (i) => {
    setCart((prevCart) =>
      prevCart.map((item, o) => {
        if (i === o && item.inCart) {
          if (item.count > 9) {
            return item;
          } else return { ...item, count: item.count + 1 };
        } else if (i === o) {
          if (item.counterVal > 9) {
            return item;
          } else
            return {
              ...item,
              counterVal: item.counterVal + 1,
            };
        }
        return item;
      })
    );
  };

  const decreaseQuantity = (i) => {
    setCart((prevCart) =>
      prevCart.map((item, o) => {
        if (i === o && item.inCart) {
          if (item.count > 1) {
            return { ...item, count: item.count - 1 };
          } else {
            return item;
          }
        } else if (i === o && item.counterVal > 1) {
          return {
            ...item,
            counterVal: item.counterVal - 1,
          };
        }
        return item;
      })
    );
  };

  const removeFromCart = (i) => {
    setCart((prevCart) =>
      prevCart.map((item, o) => {
        if (i === o) {
          return {
            ...item,
            count: 0,
            counterVal: 1,
            inCart: false,
          };
        }
        return item;
      })
    );
  };

  const cartCountTotal = cart.reduce((acc, item) => acc + item.count, 0);
  const cartPriceTotal = cart.reduce(
    (acc, item) => acc + item.price * item.count,
    0
  );

  const cartTotals = () => {
    let discoutCartPriceTotal;
    if (cartCountTotal === 0) {
      return <b>Cart is empty</b>;
    }
    if (cartCountTotal === 1) {
      discoutCartPriceTotal = cartPriceTotal - (cartPriceTotal * 10) / 100;
      return (
        <>
          <b>
            <p>Items in Cart: {cartCountTotal}</p>
            <p>Discount of 10% for one item</p>
            <p>
              Total Price after discount: Rs
              {discoutCartPriceTotal}
            </p>
          </b>
        </>
      );
    }
    if (cartCountTotal === 2) {
      discoutCartPriceTotal = cartPriceTotal - (cartPriceTotal * 20) / 100;
      return (
        <>
          <b>
            <p>Items in Cart: {cartCountTotal}</p>
            <p>Discount of 20% for two item</p>
            <p>
              Total Price after discount: Rs
              {discoutCartPriceTotal}
            </p>
          </b>
        </>
      );
    }
    if (cartCountTotal === 3 || cartCountTotal > 3) {
      discoutCartPriceTotal = cartPriceTotal - (cartPriceTotal * 30) / 100;
      return (
        <>
          <b>
            <p>Items in Cart: {cartCountTotal}</p>
            <p>Discount of 30% for three or more then three item</p>
            <p>
              Total Price after discount: Rs
              {discoutCartPriceTotal}
            </p>
          </b>
        </>
      );
    }
  };
  // cartCountTotal === 0 ? (
  //   <b>Cart is empty</b>
  // ) : (
  //   <>
  //     <b>
  //       <p>Items in Cart: {cartCountTotal}</p>
  //       <p>
  //         Total Price: Rs
  //         {Number.isInteger(cartPriceTotal)
  //           ? cartPriceTotal
  //           : cartPriceTotal.toFixed(2)}
  //       </p>
  //     </b>
  //   </>
  // );

  const cartItems = cart.map((item, i) => (
    <React.Fragment key={item.name}>
      {item.inCart && (
        <>
          <p> Item Name: {item.name}</p>
          <img src={item.img} height="100px" width="100px" />
          <p>
            Item Count:{" "}
            <button
              type="button"
              class="btn btn-success"
              onClick={() => decreaseQuantity(i)}
            >
              -
            </button>{" "}
            {item.count}{" "}
            <button
              type="button"
              class="btn btn-success"
              onClick={() => increaseQuantity(i)}
            >
              +
            </button>
          </p>
          <p>
            Item Subtotal: Rs
            {Number.isInteger(item.count * item.price)
              ? item.count * item.price
              : `${(item.count * item.price).toFixed(2)}`}
          </p>
          <button
            type="button"
            class="btn btn-danger"
            onClick={() => removeFromCart(i)}
          >
            Remove From Cart
          </button>
          <hr />
        </>
      )}
    </React.Fragment>
  ));

  const cartProducts = () => (
    <div className="flexParent">
      {cart.map((item, i) => (
        <div key={item.name}>
          <img src={item.img} height="100px" width="100px" />
          <p>{item.name}</p>
          <p>Price:{item.price}/-</p>
          {!item.inCart ? (
            <>
              <button
                type="button"
                class="btn btn-success"
                onClick={() => decreaseQuantity(i)}
              >
                -
              </button>
              <input readOnly type="text" value={item.counterVal} />
              <button
                type="button"
                class="btn btn-success"
                onClick={() => increaseQuantity(i)}
              >
                +
              </button>
              <br />
              <button
                type="button"
                class="btn btn-primary"
                onClick={() => addToCart(i)}
              >
                add
              </button>
            </>
          ) : (
            <p>
              <b>Item added!</b>
            </p>
          )}
        </div>
      ))}
    </div>
  );

  function Home() {
    return <>{cartProducts()}</>;
  }

  function Cart() {
    return (
      <>
        {cartItems}
        {cartTotals()}
      </>
    );
  }

  return (
    <Router>
      <div className="App">
        <nav class="navbar navbar-dark bg-dark">
          <a className="navbar-brand" href="/">
            Shoping Cart
          </a>
          <div className="nav navbar-nav">
            <ul className="navbar-nav mr-auto">
              <li>
                <Link to="/cart">Cart({cartCountTotal})</Link>
              </li>
            </ul>
          </div>
        </nav>
        <Routes>
          <Route path="/cart" element={<Cart />} />
          <Route path="/" element={<Home />} />
        </Routes>
      </div>
    </Router>
  );
}
export default App;
