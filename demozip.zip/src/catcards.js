import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';

function CatCards(props) {
    const mystyle = {
        maxHeight: '368px',
        objectFit: 'cover'
      };
  return (
    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" style={mystyle} src={props.image} />
      <Card.Body>
        <Card.Title>{props.name}</Card.Title>
        <Card.Text>
          {props.desc}
        </Card.Text>
        <Card.Text>
          Email : {props.email}
        </Card.Text>
        <Card.Text>
          Contact : {props.contact}
        </Card.Text>
        <Link to={props.link} style={{textDecoration:'none',color:'black'}}>
            <Button variant="primary"> Click To check {props.name} Paintings</Button>
        </Link>
      </Card.Body>
    </Card>
  );
}

export default CatCards;