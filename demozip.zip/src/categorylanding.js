import React from "react";
import CatCards from "./catcards";
import data from './datajson.json';
import { useState } from "react";

function Categorylanding() {
  // console.log(data)
  const [catid , changecatid ] = useState(window.location.href.split('=')[1])

  return (
    <div className="container my-3">
      {data.Arts.Art.map((mydata) => {
        if(mydata.artid == catid){
          return( <h2>Category - {mydata.title}</h2>)
        }
      }
      )}
      
      <div className="row">
        {data.Artists.Artist.map((mydata) => {
          if(mydata.arts.artid.toString().indexOf(catid) != -1){
            return(
              <div className="col-md-4 my-2" key={mydata.artistid}>
                <CatCards name={mydata.artistname} desc={mydata.designation} email={mydata.email} contact={mydata.contact} link={`/category/detail/artist-${mydata.artistid}`} image={`${process.env.PUBLIC_URL}/assets/${mydata.imagepath}`}/>
              </div>
            )
          }else{return ''}
        })}
      </div>
    </div>
  );
}

export default Categorylanding;