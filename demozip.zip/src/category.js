import React from "react";
import CatCards from "./catcards";
import ListGroup from 'react-bootstrap/ListGroup';
import { Link } from 'react-router-dom';
import data from './datajson.json';

function Category() {
  return (
    <>
      <div className="container my-3">
        <h1>Category</h1>
        <ListGroup>
        {data.Arts.Art.map((country) => {
          return (
            <ListGroup.Item key={country.artid}><Link to={`/category/catlanding/${country.RedirectURL}`} style={{textDecoration:'none',color:'black'}}>{country.title}</Link></ListGroup.Item>
          )
        })}
        </ListGroup>
      </div>
    </>
  );
}

export default Category;
