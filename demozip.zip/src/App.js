// import logo from './logo.svg';
import './App.css';
import NavagationBar from './navigationbar'
import 'bootstrap/dist/css/bootstrap.min.css';
import Category from './category';
import Detail from './detail'
import Home from './home'
import { Routes, Route, Outlet, Link } from "react-router-dom";
import Categorylanding from './categorylanding';
function App() {
  
  return (
    
    <>
    <NavagationBar />
    <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/category' element={<Category/>} />
        <Route path='/category/catlanding/*' element={<Categorylanding/>} />
        <Route path='/category/detail/*' element={<Detail/>} />
    </Routes>
    </>
  );
}

export default App;
