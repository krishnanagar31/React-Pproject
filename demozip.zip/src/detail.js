import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import data from './datajson.json';
import { useState } from 'react';

function Detail(props) {
  const [artistid , changeartistid ] = useState(window.location.href.split('-')[1])
    const mystyle = {
        maxHeight: '368px',
        objectFit: 'cover'
      };
  return (
    <>
    <div className="container">
      {data.Artists.Artist.map((mydata) => {
          if(mydata.artistid == artistid){
            return( <h1 className='text-center my-3'> Paintings By {mydata.artistname}</h1>)
          }
        }
        )}
      
      <div className="row">
      {data.Items.Item.map((ar) => {
        console.log(artistid)
        if(ar.artists.artistid.toString().indexOf(artistid) != -1){
        return(
          <div className="col-md-4 my-2" key={ar.ItemID}>
            <Card style={{ width: '18rem' }}>
              <Card.Body>
                <Card.Title>{ar.ItemName}</Card.Title>
                <Card.Text>
                  description : {ar.description}
                </Card.Text>
              </Card.Body>
              <Card.Img variant="top" style={mystyle} src={`${process.env.PUBLIC_URL}/assets/${ar.images.imagepath[0]}`} /> 
            </Card>
          </div>
        )}
      })}
        
      </div>
    </div>
    </>
  );
}

export default Detail;