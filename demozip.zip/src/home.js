import React from "react";
import { Link } from 'react-router-dom';

function Home() {
  return (
    <>
      <h1 className="text-center my-5">Home Page</h1>
      <h5 className="text-center my-5"><Link to={'/category'} style={{textDecoration:'none',color:'black'}}>Go to Category</Link></h5>
    </>
  );
}

export default Home;
